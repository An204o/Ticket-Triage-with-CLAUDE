"""Offline keyword classifier. Used when no API key is set and as a fallback when the model fails."""

from __future__ import annotations

import re

from .schema import Triage

_RULES = [
    ("security", "urgent", r"\b(hacked|breach|unauthori[sz]ed|stolen|leak(ed)?|phishing|compromised)\b"),
    ("account_access", "high", r"\b(can'?t (log ?in|sign ?in)|locked out|password reset|2fa|two-factor)\b"),
    ("billing", "medium", r"\b(charge[dr]?|refund|invoice|billing|payment|subscription)\b"),
    ("bug", "medium", r"\b(error|crash(es|ed)?|bug|broken|not working|fails?|exception|500)\b"),
    ("feature_request", "low", r"\b(feature request|would be great|please add|wish (you|it) (had|could))\b"),
    ("how_to", "low", r"\b(how (do|can) i|how to|where (is|do)|documentation|tutorial)\b"),
]

_REPLIES = {
    "security": "Thanks for flagging this. Our security team has been alerted and will contact you shortly. Please change your password now.",
    "account_access": "Sorry you're locked out. Please try the password reset link, and reply with the email on the account if it doesn't arrive.",
    "billing": "Thanks for reaching out about billing. We're reviewing your account and will confirm the details shortly.",
    "bug": "Sorry about the trouble. Could you share the steps to reproduce it and any error message so we can investigate?",
    "feature_request": "Thanks for the suggestion. We've logged it with the product team.",
    "how_to": "Happy to help. Here is the relevant documentation, and tell us if you get stuck.",
    "other": "Thanks for contacting us. A teammate will review your message and reply soon.",
}


def classify(text: str) -> Triage:
    lowered = text.lower()
    for category, severity, pattern in _RULES:
        if re.search(pattern, lowered):
            human = category == "security" or severity == "urgent"
            return Triage(category, severity, text.strip()[:140], _REPLIES[category], human, "rules")
    return Triage("other", "low", text.strip()[:140], _REPLIES["other"], True, "rules")
