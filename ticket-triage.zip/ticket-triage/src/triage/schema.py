"""Strict validation of model output. Anything outside the schema is rejected, never trusted."""

from __future__ import annotations

import json
from dataclasses import dataclass

CATEGORIES = ("billing", "bug", "how_to", "account_access", "feature_request", "security", "other")
SEVERITIES = ("low", "medium", "high", "urgent")


@dataclass(frozen=True)
class Triage:
    category: str
    severity: str
    summary: str
    suggested_reply: str
    needs_human: bool
    source: str  # "model", "rules" or "fallback"


def parse_reply(raw: str, source: str = "model") -> Triage:
    """Parse a model reply. Raises ValueError on any schema violation."""
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"reply is not JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("reply must be a JSON object")
    category, severity = data.get("category"), data.get("severity")
    if category not in CATEGORIES:
        raise ValueError(f"bad category: {category!r}")
    if severity not in SEVERITIES:
        raise ValueError(f"bad severity: {severity!r}")
    summary, reply = data.get("summary"), data.get("suggested_reply")
    if not isinstance(summary, str) or not summary.strip() or len(summary) > 300:
        raise ValueError("summary must be 1-300 characters")
    if not isinstance(reply, str) or not reply.strip() or len(reply) > 1500:
        raise ValueError("suggested_reply must be 1-1500 characters")
    needs_human = data.get("needs_human")
    if not isinstance(needs_human, bool):
        raise ValueError("needs_human must be true or false")
    # Security issues and urgent tickets always reach a person, whatever the model says.
    if category == "security" or severity == "urgent":
        needs_human = True
    return Triage(category, severity, summary.strip(), reply.strip(), needs_human, source)
