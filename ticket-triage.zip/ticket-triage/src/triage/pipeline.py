from __future__ import annotations

from . import rules
from .client import Completion, build_prompt
from .schema import Triage, parse_reply


def triage_ticket(text: str, complete: Completion | None = None, retries: int = 1) -> Triage:
    """Model first (if given), validated strictly; fall back to rules so a bad reply never drops a ticket."""
    if not text.strip():
        raise ValueError("empty ticket")
    if complete is not None:
        for _ in range(retries + 1):
            try:
                return parse_reply(complete(build_prompt(text)))
            except Exception:  # bad JSON, schema violation, network error: retry, then fall back
                continue
        fallback = rules.classify(text)
        return Triage(**{**fallback.__dict__, "source": "fallback", "needs_human": True})
    return rules.classify(text)
