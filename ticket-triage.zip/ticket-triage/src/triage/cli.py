from __future__ import annotations

import argparse
import json
from pathlib import Path

from .client import claude_completion
from .pipeline import triage_ticket

ORDER = {"urgent": 0, "high": 1, "medium": 2, "low": 3}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="triage", description="Triage support tickets with Claude or offline rules.")
    parser.add_argument("tickets", type=Path, help="JSON file: a list of {id, text}")
    parser.add_argument("--model", action="store_true", help="use the Claude API (needs ANTHROPIC_API_KEY)")
    parser.add_argument("--out", type=Path, help="write a Markdown report here")
    args = parser.parse_args(argv)

    complete = claude_completion() if args.model else None
    results = [(t["id"], t["text"], triage_ticket(t["text"], complete)) for t in json.loads(args.tickets.read_text())]
    results.sort(key=lambda r: ORDER[r[2].severity])

    lines = ["| Ticket | Severity | Category | Human? | Source | Summary |", "|---|---|---|---|---|---|"]
    for ticket_id, _, r in results:
        lines.append(f"| {ticket_id} | {r.severity} | {r.category} | {'yes' if r.needs_human else 'no'} | {r.source} | {r.summary} |")
    report = "\n".join(lines)
    print(report)
    if args.out:
        args.out.write_text(report + "\n", encoding="utf-8")
    return 0
